"""
    游戏入口
"""
from usl import GameConsoleView

if __name__ =="__main__":
    view = GameConsoleView()
    view.main()