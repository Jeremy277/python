# Game Over
# Demonstrates the print function

print("Game Over")

input("\n\nPress the enter key to exit.")
