# Personal Greeter
# Demonstrates getting user input

name = input("Hi.  What's your name? ")

print(name)

print("Hi,", name)

input("\n\nPress the enter key to exit.")
