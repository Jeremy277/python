# Fancy Credits
# Demonstrates escape sequences

print("\t\t\tFancy Credits")

print("\t\t\t \\ \\ \\ \\ \\ \\ \\")
print("\t\t\t\tby")
print("\t\t\tMichael Dawson")
print("\t\t\t \\ \\ \\ \\ \\ \\ \\")

print("\nSpecial thanks goes out to:")
print("My hair stylist, Henry \'The Great,\' who never says \"can\'t.\"")

# sound the system bell
print("\a")

input("\n\nPress the enter key to exit.")


