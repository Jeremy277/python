                         THE PYTHON LANGUAGE
                                3.1.1


Dependencies
------------
Although Python is cross-platform, the file that accompanies these 
instructions will only work with Windows. If you have another 
operating system, please see the official Python web site.


Installation
------------
To install Python, simply run the Python set-up program, 
python-3.1.1.msi, by double-clicking it, and follow the prompts.  
You may accept all default settings.


Testing
-------
From the Start menu, choose Programs, Python 3.1, choose IDLE (Python GUI).  
If IDLE does not appear, you may need to update your PATH to include the 
folder in which you installed Python. 


Official Site
-------------
For more information, visit the official Python web site at 
http://www.python.org.
